import { useEffect } from "react";
import { SideNavigation } from "../components/layout/side-navigation";
import { Footer } from "../components/layout/footer";
import { CustomCursor } from "../components/ui/custom-cursor";
import { NavigationOptions } from "../components/ui/navigation-options";
import { Hero } from "../components/sections/hero";
import { ProblemStack } from "../components/sections/problem-stack";
import { SchemaGrid } from "../components/sections/schema-grid";
import { AgentPanel } from "../components/sections/agent-panel";
import { ToolZone } from "../components/sections/tool-zone";

export default function Home() {
  useEffect(() => {
    // Random glitch effects on tiles
    const triggerRandomGlitch = () => {
      const tiles = document.querySelectorAll('.glitch-tile');
      const randomTile = tiles[Math.floor(Math.random() * tiles.length)];
      if (randomTile) {
        (randomTile as HTMLElement).style.animation = 'glitch 0.2s ease-in-out';
        setTimeout(() => {
          (randomTile as HTMLElement).style.animation = 'none';
        }, 200);
      }
    };

    // Set up intervals
    const glitchInterval = setInterval(triggerRandomGlitch, Math.random() * 4000 + 3000);

    // Cleanup
    return () => {
      clearInterval(glitchInterval);
    };
  }, []);

  return (
    <>
      <CustomCursor />
      <SideNavigation />
      
      <NavigationOptions mode="tunnel">
        <Hero />
        <ProblemStack />
        <SchemaGrid />
        <AgentPanel />
        <ToolZone />
      </NavigationOptions>
      
      <Footer />
    </>
  );
}
