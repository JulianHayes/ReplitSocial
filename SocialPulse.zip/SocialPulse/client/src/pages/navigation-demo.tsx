import { useState } from "react";
import { NavigationOptions } from "../components/ui/navigation-options";
import { Hero } from "../components/sections/hero";
import { ProblemStack } from "../components/sections/problem-stack";
import { SchemaGrid } from "../components/sections/schema-grid";
import { AgentPanel } from "../components/sections/agent-panel";
import { ToolZone } from "../components/sections/tool-zone";
import { CustomCursor } from "../components/ui/custom-cursor";
import { Navigation } from "../components/layout/navigation";
import { Footer } from "../components/layout/footer";

export default function NavigationDemo() {
  const [currentMode, setCurrentMode] = useState<"stack" | "tunnel" | "cube" | "sphere" | "matrix">("tunnel");

  const modes = [
    { key: "stack", label: "Stack Mode", description: "Vertical stacking with depth" },
    { key: "tunnel", label: "Tunnel Mode", description: "Deep Z-axis movement" },
    { key: "cube", label: "Cube Mode", description: "3D rotation like a cube" },
    { key: "sphere", label: "Sphere Mode", description: "Orbital movement" },
    { key: "matrix", label: "Matrix Mode", description: "Grid-like transitions" }
  ];

  return (
    <>
      <CustomCursor />
      <Navigation />
      
      {/* Mode Selector */}
      <div className="fixed top-20 left-4 z-50 bg-black/80 backdrop-blur-sm border border-brand-orange rounded-lg p-4">
        <h3 className="text-brand-orange font-bold mb-3 text-sm">Navigation Modes</h3>
        <div className="space-y-2">
          {modes.map((mode) => (
            <button
              key={mode.key}
              onClick={() => setCurrentMode(mode.key as any)}
              className={`block w-full text-left p-2 rounded text-xs transition-all ${
                currentMode === mode.key 
                  ? 'bg-brand-orange text-black' 
                  : 'text-brand-orange hover:bg-brand-orange/20'
              }`}
            >
              <div className="font-bold">{mode.label}</div>
              <div className="text-xs opacity-75">{mode.description}</div>
            </button>
          ))}
        </div>
      </div>

      <NavigationOptions mode={currentMode}>
        <Hero />
        <ProblemStack />
        <SchemaGrid />
        <AgentPanel />
        <ToolZone />
      </NavigationOptions>
      
      <Footer />
    </>
  );
}