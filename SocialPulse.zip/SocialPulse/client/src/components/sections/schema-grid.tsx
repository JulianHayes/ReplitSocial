import { motion } from "framer-motion";
import { VellumInterface } from "../ui/vellum-interface";

const schemaItems = [
  {
    title: "BRAND MATRIX",
    description: "Core identity structure and relationship mapping",
    path: "./identity/core.schema",
  },
  {
    title: "TONE MAP",
    description: "Semantic voice patterns and expression protocols",
    path: "./voice/tone.config",
  },
  {
    title: "PROMPT STACK",
    description: "Instruction hierarchy and response frameworks",
    path: "./prompts/stack.json",
  },
  {
    title: "METADATA LAYER",
    description: "Contextual information and semantic tags",
    path: "./meta/context.db",
  },
];

export function SchemaGrid() {
  return (
    <section className="bg-dark-bg w-full h-full relative">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="max-w-6xl mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-3xl md:text-5xl font-black mb-16 text-center text-distort depth-layer-1"
          >
            BRAND AS SCHEMA
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {schemaItems.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`depth-vellum-${index % 3 + 2}`}
              >
                <VellumInterface depth={index % 3 + 2} isActive={true} variant="panel">
                  <div className="glitch-tile">
                    <h3 className="text-xl font-bold mb-4 text-brand-orange font-mono">
                      {item.title}
                    </h3>
                    <p className="text-sm mb-4">{item.description}</p>
                    <div className="text-xs font-mono text-gray-400">
                      {item.path}
                    </div>
                  </div>
                </VellumInterface>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
