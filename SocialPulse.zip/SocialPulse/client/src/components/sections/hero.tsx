import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { VellumInterface } from "../ui/vellum-interface";

export function Hero() {
  const [headlineText, setHeadlineText] = useState("YOU CAN'T TOUCH A BRAND ANYMORE.\nBUT YOU CAN SENSE IT.");

  useEffect(() => {
    const originalText = "YOU CAN'T TOUCH A BRAND ANYMORE.\nBUT YOU CAN SENSE IT.";
    const leetText = "Y0U C4N'T T0UCH 4 BR4ND 4NYM0R3.\nBUT Y0U C4N S3NS3 1T.";
    const randomChars = "!@#$%^&*()_+[]{}|;:,.<>?";
    
    let currentStep = 0;
    const totalSteps = 30; // 1 second / 33ms per frame
    
    const animate = () => {
      if (currentStep < totalSteps) {
        const progress = currentStep / totalSteps;
        let newText = "";
        
        for (let i = 0; i < originalText.length; i++) {
          const char = originalText[i];
          if (char === '\n' || char === ' ' || char === '.' || char === "'") {
            newText += char;
          } else if (progress < 0.4) {
            // Random characters phase
            newText += randomChars[Math.floor(Math.random() * randomChars.length)];
          } else if (progress < 0.7) {
            // Leet speak phase
            newText += leetText[i];
          } else {
            // Final text phase
            newText += originalText[i];
          }
        }
        
        setHeadlineText(newText);
        currentStep++;
        setTimeout(animate, 33);
      } else {
        setHeadlineText(originalText);
      }
    };
    
    // Start animation after component mounts
    setTimeout(() => {
      animate();
    }, 800);
  }, []);

  return (
    <section className="hero-bg relative w-full h-full">
      <div className="absolute inset-0 flex items-center justify-center">
        <VellumInterface depth={1} isActive={true} variant="overlay">
          <div className="text-center max-w-4xl mx-auto px-6">
            <motion.h2
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-4xl md:text-6xl font-black mb-8 text-distort depth-vellum-1"
            >
              {headlineText.split('\n').map((line, index) => (
                <span key={index}>
                  {line}
                  {index === 0 && <br />}
                </span>
              ))}
            </motion.h2>
          
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-xl md:text-2xl mb-12 font-light leading-relaxed depth-vellum-2"
            >
              In an AI-mediated world, brand presence exists as trace—semantic, ambient, untouchable.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center depth-vellum-3"
            >
              <VellumInterface depth={2} isActive={true} variant="card">
                <button className="bg-brand-orange hover:bg-brand-red text-black dark:text-black font-bold py-4 px-8 text-lg transition-all duration-300 text-distort">
                  [ SENSE THE SCHEMA ]
                </button>
              </VellumInterface>
              <VellumInterface depth={2} isActive={true} variant="card">
                <button 
                  onClick={() => window.location.href = '/demo'}
                  className="border-2 border-brand-orange hover:bg-brand-orange hover:text-black dark:hover:text-black text-foreground font-bold py-4 px-8 text-lg transition-all duration-300 text-distort"
                >
                  [ VIEW NAVIGATION DEMO ]
                </button>
              </VellumInterface>
            </motion.div>
          </div>
        </VellumInterface>
      </div>
    </section>
  );
}
