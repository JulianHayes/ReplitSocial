import { motion } from "framer-motion";
import { VellumInterface } from "../ui/vellum-interface";

const agents = [
  {
    name: "STRATEGY AGENT",
    description: "Long-term planning and strategic positioning",
    status: "ACTIVE",
    color: "brand-green",
  },
  {
    name: "MANAGEMENT AGENT",
    description: "Process optimization and workflow control",
    status: "ACTIVE",
    color: "brand-green",
  },
  {
    name: "MARKETING AGENT",
    description: "Message distribution and audience engagement",
    status: "PROCESSING",
    color: "brand-orange",
  },
  {
    name: "INTELLIGENCE AGENT",
    description: "Data analysis and pattern recognition",
    status: "ACTIVE",
    color: "brand-green",
  },
];

export function AgentPanel() {
  return (
    <section className="bg-dark-bg w-full h-full relative">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="max-w-6xl mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-3xl md:text-5xl font-black mb-16 text-center text-distort depth-layer-1"
          >
            AGENT PANEL
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {agents.map((agent, index) => (
              <motion.div
                key={agent.name}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`depth-vellum-${index % 3 + 2}`}
              >
                <VellumInterface depth={index % 3 + 2} isActive={true} variant="panel">
                  <div className="glitch-tile">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold text-brand-orange font-mono">
                        {agent.name}
                      </h3>
                      <div className={`w-3 h-3 bg-${agent.color} rounded-full`}></div>
                    </div>
                    <p className="text-sm mb-4">{agent.description}</p>
                    <div className="text-xs font-mono text-gray-400">
                      status: {agent.status}
                    </div>
                  </div>
                </VellumInterface>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
