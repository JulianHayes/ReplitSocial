import { motion } from "framer-motion";
import { VellumInterface } from "../ui/vellum-interface";

const tools = [
  {
    name: "SCHEMA BUILDER",
    description: "Construct and validate brand schema structures",
    action: "LAUNCH BUILDER",
  },
  {
    name: "LLM VISIBILITY MAP",
    description: "Track brand presence across AI training data",
    action: "VIEW MAP",
  },
  {
    name: "PROMPT LIBRARY",
    description: "Repository of tested brand interaction patterns",
    action: "ACCESS LIBRARY",
  },
];

export function ToolZone() {
  return (
    <section className="bg-dark-bg w-full h-full relative">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="max-w-6xl mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-3xl md:text-5xl font-black mb-16 text-center text-distort depth-layer-1"
          >
            TOOL ZONE
          </motion.h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {tools.map((tool, index) => (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className={`depth-vellum-${index + 2}`}
              >
                <VellumInterface depth={index + 2} isActive={true} variant="panel">
                  <div className="glitch-tile">
                    <h3 className="text-2xl font-bold mb-4 text-brand-orange font-mono">
                      {tool.name}
                    </h3>
                    <p className="text-sm mb-6">{tool.description}</p>
                    <VellumInterface depth={index + 3} isActive={true} variant="card">
                      <button className="bg-brand-orange text-black dark:text-black px-4 py-2 font-bold text-sm hover:bg-brand-red transition-all duration-300">
                        {tool.action}
                      </button>
                    </VellumInterface>
                  </div>
                </VellumInterface>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
