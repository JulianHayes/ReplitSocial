import { motion } from "framer-motion";
import { VellumInterface } from "../ui/vellum-interface";

const problems = [
  { id: "01", text: "The homepage is gone." },
  { id: "02", text: "Loyalty moved upstream." },
  { id: "03", text: "Emotion without structure is noise." },
];

export function ProblemStack() {
  return (
    <section className="bg-dark-bg w-full h-full relative">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="max-w-6xl mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-3xl md:text-5xl font-black mb-16 text-center text-distort depth-layer-1"
          >
            PROBLEM STACK
          </motion.h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {problems.map((problem, index) => (
              <motion.div
                key={problem.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className={`depth-vellum-${index + 2}`}
              >
                <VellumInterface depth={index + 2} isActive={true} variant="panel">
                  <div className="text-center glitch-tile">
                    <h3 className="text-2xl font-bold mb-4 text-brand-orange">
                      {problem.id}
                    </h3>
                    <p className="text-xl font-mono">{problem.text}</p>
                  </div>
                </VellumInterface>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
