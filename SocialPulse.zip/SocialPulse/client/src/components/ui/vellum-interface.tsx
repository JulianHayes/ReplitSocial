import { useEffect, useRef, useState } from "react";

interface VellumInterfaceProps {
  children: React.ReactNode;
  depth: number;
  isActive: boolean;
  variant?: 'card' | 'panel' | 'overlay';
}

export function VellumInterface({ 
  children, 
  depth, 
  isActive, 
  variant = 'card' 
}: VellumInterfaceProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const elementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (elementRef.current) {
        const rect = elementRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;
        const y = (e.clientY - rect.top) / rect.height;
        setMousePosition({ x, y });
      }
    };

    const element = elementRef.current;
    if (element) {
      element.addEventListener('mousemove', handleMouseMove);
      return () => element.removeEventListener('mousemove', handleMouseMove);
    }
  }, []);

  const getVellumStyle = () => {
    const baseOpacity = isActive ? 0.9 : 0.6;
    const blurIntensity = isActive ? 10 : 5;
    const zTransform = isActive ? 0 : -depth * 50;
    
    return {
      background: `
        radial-gradient(circle at ${mousePosition.x * 100}% ${mousePosition.y * 100}%, 
          rgba(255, 255, 255, ${baseOpacity * 0.15}), 
          rgba(255, 255, 255, ${baseOpacity * 0.05}) 50%,
          transparent 100%
        ),
        linear-gradient(145deg, 
          rgba(255, 69, 0, ${baseOpacity * 0.1}), 
          rgba(220, 20, 60, ${baseOpacity * 0.05})
        )
      `,
      backdropFilter: `blur(${blurIntensity}px) saturate(180%)`,
      border: `1px solid rgba(255, 255, 255, ${baseOpacity * 0.2})`,
      boxShadow: `
        0 8px 32px rgba(0, 0, 0, ${baseOpacity * 0.3}),
        inset 0 1px 0 rgba(255, 255, 255, ${baseOpacity * 0.2}),
        0 0 20px rgba(255, 69, 0, ${baseOpacity * 0.1})
      `,
      transform: `
        translateZ(${zTransform}px) 
        rotateX(${mousePosition.y * 5 - 2.5}deg) 
        rotateY(${mousePosition.x * 5 - 2.5}deg)
      `,
      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    };
  };

  const getVariantClasses = () => {
    switch (variant) {
      case 'panel':
        return 'vellum-panel';
      case 'overlay':
        return 'vellum-overlay';
      default:
        return 'vellum-card';
    }
  };

  return (
    <div 
      ref={elementRef}
      className={`vellum-interface ${getVariantClasses()}`}
      style={getVellumStyle()}
    >
      <div className="vellum-content">
        {children}
      </div>
      
      {/* Ambient light effect */}
      <div 
        className="vellum-light"
        style={{
          background: `radial-gradient(circle at ${mousePosition.x * 100}% ${mousePosition.y * 100}%, 
            rgba(255, 69, 0, 0.1), 
            transparent 60%
          )`,
        }}
      />
    </div>
  );
}