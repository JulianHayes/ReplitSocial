import { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface TravelSystemProps {
  children: React.ReactNode[];
}

export function TravelSystem({ children }: TravelSystemProps) {
  const [currentSection, setCurrentSection] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const navigateToSection = (index: number) => {
    if (index === currentSection || isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentSection(index);
    
    // Add forward movement animation to container
    const container = containerRef.current;
    if (container) {
      container.style.transform = `translateZ(${index * -150}px) rotateX(${index * 1.5}deg)`;
    }
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 1000);
  };

  const nextSection = () => {
    if (currentSection < children.length - 1) {
      navigateToSection(currentSection + 1);
    }
  };

  const prevSection = () => {
    if (currentSection > 0) {
      navigateToSection(currentSection - 1);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "ArrowRight") {
        nextSection();
      } else if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
        prevSection();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentSection]);

  // Wheel navigation
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (Math.abs(e.deltaY) > 30) {
        if (e.deltaY > 0) {
          nextSection();
        } else {
          prevSection();
        }
      }
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener("wheel", handleWheel, { passive: false });
      return () => container.removeEventListener("wheel", handleWheel);
    }
  }, [currentSection]);

  // Navigation events
  useEffect(() => {
    const handleTravelNavigate = (e: CustomEvent) => {
      navigateToSection(e.detail.index);
    };

    window.addEventListener('travel-navigate', handleTravelNavigate as EventListener);
    return () => window.removeEventListener('travel-navigate', handleTravelNavigate as EventListener);
  }, []);

  const getSectionClass = (index: number) => {
    if (index === currentSection) return "active";
    if (index === currentSection + 1) return "next";
    if (index === currentSection - 1) return "prev";
    return "far";
  };

  return (
    <div className="travel-container" ref={containerRef}>
      {/* Floating depth particles */}
      <div className="depth-particle" style={{ top: "10%", left: "10%", transform: "translateZ(-100px)" }}>
        <div className="w-4 h-4 bg-brand-orange opacity-30 rounded-full animate-pulse"></div>
      </div>
      <div className="depth-particle" style={{ top: "20%", right: "15%", transform: "translateZ(-200px)" }}>
        <div className="w-6 h-6 bg-brand-red opacity-20 rounded-full animate-pulse"></div>
      </div>
      <div className="depth-particle" style={{ top: "60%", left: "20%", transform: "translateZ(-300px)" }}>
        <div className="w-3 h-3 bg-brand-green opacity-35 rounded-full animate-pulse"></div>
      </div>
      <div className="depth-particle" style={{ bottom: "20%", right: "10%", transform: "translateZ(-150px)" }}>
        <div className="w-5 h-5 bg-brand-orange opacity-15 rounded-full animate-pulse"></div>
      </div>
      <div className="depth-particle" style={{ top: "30%", left: "50%", transform: "translateZ(-400px)" }}>
        <div className="w-2 h-2 bg-brand-red opacity-25 rounded-full animate-pulse"></div>
      </div>
      <div className="depth-particle" style={{ bottom: "40%", left: "70%", transform: "translateZ(-250px)" }}>
        <div className="w-4 h-4 bg-brand-green opacity-20 rounded-full animate-pulse"></div>
      </div>
      <div className="depth-particle" style={{ top: "70%", right: "30%", transform: "translateZ(-350px)" }}>
        <div className="w-3 h-3 bg-brand-orange opacity-28 rounded-full animate-pulse"></div>
      </div>
      <div className="depth-particle" style={{ bottom: "10%", left: "30%", transform: "translateZ(-180px)" }}>
        <div className="w-5 h-5 bg-brand-red opacity-18 rounded-full animate-pulse"></div>
      </div>

      {/* Sections */}
      {children.map((child, index) => (
        <div
          key={index}
          className={`travel-section ${getSectionClass(index)}`}
          style={{ zIndex: children.length - Math.abs(index - currentSection) }}
        >
          <div className="w-full h-full relative">
            {child}
          </div>
        </div>
      ))}

      {/* Section navigation dots */}
      <div className="section-nav">
        {children.map((_, index) => (
          <button
            key={index}
            className={`section-dot ${index === currentSection ? "active" : ""}`}
            onClick={() => navigateToSection(index)}
            aria-label={`Go to section ${index + 1}`}
          />
        ))}
      </div>

      {/* Navigation arrows */}
      <button
        onClick={prevSection}
        disabled={currentSection === 0}
        className="fixed left-6 top-1/2 transform -translate-y-1/2 z-50 p-3 bg-dark-card border-2 border-transparent hover:border-brand-orange transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed"
        aria-label="Previous section"
      >
        <ChevronLeft className="w-6 h-6 text-brand-orange" />
      </button>

      <button
        onClick={nextSection}
        disabled={currentSection === children.length - 1}
        className="fixed right-6 top-1/2 transform -translate-y-1/2 z-50 p-3 bg-dark-card border-2 border-transparent hover:border-brand-orange transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed"
        aria-label="Next section"
      >
        <ChevronRight className="w-6 h-6 text-brand-orange" />
      </button>

      {/* Section counter */}
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 font-mono text-sm text-brand-orange">
        {String(currentSection + 1).padStart(2, '0')} / {String(children.length).padStart(2, '0')}
      </div>
    </div>
  );
}