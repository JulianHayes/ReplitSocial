import { ThemeProvider } from "../../hooks/use-theme";

export { ThemeProvider, useTheme } from "../../hooks/use-theme";
