import { useState, useEffect, useRef } from "react";
import { AmbientBackground } from "./ambient-background";

interface NavigationOptionsProps {
  children: React.ReactNode[];
  mode: "stack" | "tunnel" | "cube" | "sphere" | "matrix";
}

export function NavigationOptions({ children, mode }: NavigationOptionsProps) {
  const [currentSection, setCurrentSection] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const navigateToSection = (index: number) => {
    if (index === currentSection || isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentSection(index);
    
    // Emit section change event
    const event = new CustomEvent('section-changed', { detail: { currentSection: index } });
    window.dispatchEvent(event);
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 1000);
  };

  const nextSection = () => {
    if (currentSection < children.length - 1) {
      navigateToSection(currentSection + 1);
    }
  };

  const prevSection = () => {
    if (currentSection > 0) {
      navigateToSection(currentSection - 1);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "ArrowRight") {
        nextSection();
      } else if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
        prevSection();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentSection]);

  // Navigation events
  useEffect(() => {
    const handleTravelNavigate = (e: CustomEvent) => {
      navigateToSection(e.detail.index);
    };

    window.addEventListener('travel-navigate', handleTravelNavigate as EventListener);
    return () => window.removeEventListener('travel-navigate', handleTravelNavigate as EventListener);
  }, []);

  const getSectionClass = (index: number) => {
    const diff = index - currentSection;
    if (diff === 0) return "active";
    if (diff === 1) return "next";
    if (diff === -1) return "prev";
    if (diff > 1) return "far-next";
    return "far-prev";
  };

  const getContainerClass = () => {
    return `navigation-container ${mode}-mode`;
  };

  return (
    <div className={getContainerClass()} ref={containerRef}>
      {/* Depth particles for all modes */}
      <div className="depth-particles">
        {Array.from({ length: 12 }, (_, i) => (
          <div
            key={i}
            className="depth-particle"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              transform: `translateZ(${-100 - Math.random() * 500}px)`,
              animationDelay: `${Math.random() * 6}s`
            }}
          >
            <div className={`w-${Math.floor(Math.random() * 4) + 2} h-${Math.floor(Math.random() * 4) + 2} bg-brand-orange opacity-${Math.floor(Math.random() * 30) + 10} rounded-full animate-pulse`}></div>
          </div>
        ))}
      </div>

      {/* Sections */}
      {children.map((child, index) => (
        <div
          key={index}
          className={`nav-section ${getSectionClass(index)}`}
          style={{ zIndex: children.length - Math.abs(index - currentSection) }}
        >
          <AmbientBackground 
            sectionIndex={index}
            isActive={index === currentSection}
          />
          <div className="section-content">
            {child}
          </div>
        </div>
      ))}


    </div>
  );
}