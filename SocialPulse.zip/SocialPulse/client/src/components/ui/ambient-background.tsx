import { useEffect, useRef } from "react";

interface AmbientBackgroundProps {
  sectionIndex: number;
  isActive: boolean;
}

export function AmbientBackground({ sectionIndex, isActive }: AmbientBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Create floating ambient particles
    const particleCount = 20;
    const particles: HTMLElement[] = [];

    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'ambient-particle';
      particle.style.cssText = `
        position: absolute;
        width: ${Math.random() * 4 + 2}px;
        height: ${Math.random() * 4 + 2}px;
        background: rgba(255, 69, 0, ${Math.random() * 0.3 + 0.1});
        border-radius: 50%;
        left: ${Math.random() * 100}%;
        top: ${Math.random() * 100}%;
        transform: translateZ(${Math.random() * 200 - 100}px);
        animation: ambientFloat ${Math.random() * 20 + 10}s infinite linear;
        pointer-events: none;
      `;
      
      container.appendChild(particle);
      particles.push(particle);
    }

    // Cleanup
    return () => {
      particles.forEach(particle => {
        if (particle.parentNode) {
          particle.parentNode.removeChild(particle);
        }
      });
    };
  }, []);

  const getAmbientColor = () => {
    const colors = [
      'rgba(255, 69, 0, 0.05)',   // Orange for hero
      'rgba(220, 20, 60, 0.05)',  // Red for problems
      'rgba(0, 255, 0, 0.05)',    // Green for schema
      'rgba(138, 43, 226, 0.05)', // Purple for agents
      'rgba(255, 165, 0, 0.05)'   // Gold for tools
    ];
    return colors[sectionIndex] || colors[0];
  };

  const getDepthBlur = () => {
    return isActive ? 0 : Math.abs(sectionIndex * 2);
  };

  return (
    <div 
      ref={containerRef}
      className="ambient-background"
      style={{
        background: `radial-gradient(circle at 50% 50%, ${getAmbientColor()}, transparent 70%)`,
        filter: `blur(${getDepthBlur()}px)`,
        transform: `translateZ(${isActive ? 0 : -100 * sectionIndex}px)`,
        opacity: isActive ? 1 : 0.3,
      }}
    />
  );
}