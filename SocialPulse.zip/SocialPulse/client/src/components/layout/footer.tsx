import { useEffect, useState } from "react";

export function Footer() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight;
      const scrollTop = document.documentElement.scrollTop;
      const clientHeight = document.documentElement.clientHeight;
      
      // Show footer when near bottom (within 100px)
      const nearBottom = scrollTop + clientHeight >= scrollHeight - 100;
      setIsVisible(nearBottom);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <footer className={`fixed bottom-0 left-10 right-0 z-50 glass-nav px-6 py-6 transition-transform duration-300 ${isVisible ? 'translate-y-0' : 'translate-y-full'}`}>
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <div className="text-sm font-mono">
          BRAND:SCHEMA v2.1.0
        </div>
        <div className="flex items-center space-x-4">
          <a href="#" className="social-link" aria-label="Discord">
            Ds
          </a>
          <a href="#" className="social-link" aria-label="Reddit">
            Rd
          </a>
          <a href="#" className="social-link" aria-label="LinkedIn">
            Li
          </a>
          <a href="#" className="social-link" aria-label="GitHub">
            Gh
          </a>
        </div>
      </div>
    </footer>
  );
}
