import { useTheme } from "../ui/theme-provider";
import { Home, Grid3X3, Bot, Wrench, Sun, Moon } from "lucide-react";
import { useState, useEffect } from "react";

export function Navigation() {
  const { theme, setTheme } = useTheme();
  const [logoText, setLogoText] = useState("BRAND:SCHEMA");

  const navigateToSection = (sectionIndex: number) => {
    // Trigger navigation through the travel system
    const event = new CustomEvent('travel-navigate', { detail: { index: sectionIndex } });
    window.dispatchEvent(event);
  };

  const navItems = [
    { icon: Home, label: "H0M3", action: () => navigateToSection(0) },
    { icon: Grid3X3, label: "SCH3MA", action: () => navigateToSection(2) },
    { icon: Bot, label: "AG3NT5", action: () => navigateToSection(3) },
    { icon: Wrench, label: "T00L5", action: () => navigateToSection(4) },
    { icon: theme === "dark" ? Sun : Moon, label: "TH3M3", action: () => setTheme(theme === "dark" ? "light" : "dark") },
  ];

  // Character transformation effect
  useEffect(() => {
    const originalText = "BRAND:SCHEMA";
    const leetText = "BR4ND:SCH3MA";
    const randomChars = "!@#$%^&*()_+[]{}|;:,.<>?";
    
    let currentStep = 0;
    const totalSteps = 30; // 1 second / 33ms per frame
    
    const animate = () => {
      if (currentStep < totalSteps) {
        const progress = currentStep / totalSteps;
        let newText = "";
        
        for (let i = 0; i < originalText.length; i++) {
          const char = originalText[i];
          if (char === ':') {
            newText += ':';
          } else if (progress < 0.4) {
            // Random characters phase
            newText += randomChars[Math.floor(Math.random() * randomChars.length)];
          } else if (progress < 0.7) {
            // Leet speak phase
            newText += leetText[i];
          } else {
            // Final text phase
            newText += originalText[i];
          }
        }
        
        setLogoText(newText);
        currentStep++;
        setTimeout(animate, 33);
      } else {
        setLogoText(originalText);
      }
    };
    
    animate();
  }, []);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-nav px-6 py-2">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <h1 className="text-lg font-bold font-mono">
          {logoText.split(':').map((part, index) => (
            <span key={index}>
              {part}
              {index === 0 && <span className="colon-pulse">:</span>}
            </span>
          ))}
        </h1>
        
        <div className="flex items-center nav-container">
          {navItems.map((item, index) => (
            <div key={index} className="nav-item-wrapper">
              <button
                onClick={item.action}
                className="nav-item"
                aria-label={item.label}
              >
                <item.icon size={16} />
                <span className="nav-text">{item.label}</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </nav>
  );
}
