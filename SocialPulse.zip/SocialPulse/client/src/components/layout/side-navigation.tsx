import { useState, useEffect } from "react";
import { useTheme } from "../ui/theme-provider";
import { Home, Grid3X3, Bot, Wrench, Sun, Moon, Layers } from "lucide-react";

const GlossyBrandLogo = () => (
  <svg 
    width="48" 
    height="48" 
    viewBox="0 0 300 300" 
    className="glossy-brand-logo"
    style={{ filter: 'drop-shadow(0 0 8px rgba(255, 11, 0, 0.4))' }}
  >
    <defs>
      <linearGradient id="glossyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ff0b00" stopOpacity="1"/>
        <stop offset="30%" stopColor="#ff4500" stopOpacity="0.9"/>
        <stop offset="70%" stopColor="#cc0900" stopOpacity="0.8"/>
        <stop offset="100%" stopColor="#990700" stopOpacity="1"/>
      </linearGradient>
      <linearGradient id="highlightGradient" x1="0%" y1="0%" x2="100%" y2="50%">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4"/>
        <stop offset="50%" stopColor="#ffffff" stopOpacity="0.1"/>
        <stop offset="100%" stopColor="#ffffff" stopOpacity="0"/>
      </linearGradient>
    </defs>
    <g fill="url(#glossyGradient)">
      <rect width="30" height="30" rx="6.22" ry="6.22" transform="translate(150 120)"/>
      <rect width="30" height="30" rx="6.22" ry="6.22" transform="translate(60 120)"/>
      <rect width="30" height="30" rx="6.22" ry="6.22" transform="translate(240 120)"/>
      <rect width="60" height="30" rx="6.22" ry="6.22" transform="translate(90 150)"/>
      <rect width="60" height="30" rx="6.22" ry="6.22" transform="translate(90 30)"/>
      <rect width="60" height="30" rx="6.22" ry="6.22" transform="translate(90 90)"/>
      <rect width="60" height="30" rx="6.22" ry="6.22" transform="translate(180 90)"/>
      <rect width="60" height="30" rx="6.22" ry="6.22" transform="translate(180 150)"/>
      <rect width="60" height="30" rx="6.22" ry="6.22" transform="translate(180 30)"/>
      <rect width="30" height="30" rx="6.22" ry="6.22" transform="translate(60 60)"/>
      <rect width="30" height="30" rx="6.22" ry="6.22" transform="translate(240 60)"/>
      <rect width="30" height="30" rx="6.22" ry="6.22" transform="translate(150 60)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(125.5 90.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(65.5 90.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(215.5 90.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(215.5 120.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(155.5 90.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(155.5 60.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(125.5 60.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(125.5 120.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6+6Z" transform="translate(65.5 120.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(65.5 60.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(65.5 30.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(125.5 30.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(155.5 30.5)"/>
      <path d="M30.5,29.5c-3.489524,1.386667-4.613333,2.510476-6,6-1.386667-3.489524-2.510476-4.613333-6-6c3.489524-1.386667,4.613333-2.510476,6-6c1.386667,3.489524,2.510476,4.613333,6,6Z" transform="translate(215.5 30.5)"/>
    </g>
    <g fill="url(#highlightGradient)" opacity="0.6">
      <rect width="30" height="15" rx="6.22" ry="6.22" transform="translate(150 120)"/>
      <rect width="30" height="15" rx="6.22" ry="6.22" transform="translate(60 120)"/>
      <rect width="30" height="15" rx="6.22" ry="6.22" transform="translate(240 120)"/>
      <rect width="60" height="15" rx="6.22" ry="6.22" transform="translate(90 150)"/>
      <rect width="60" height="15" rx="6.22" ry="6.22" transform="translate(90 30)"/>
      <rect width="60" height="15" rx="6.22" ry="6.22" transform="translate(90 90)"/>
      <rect width="60" height="15" rx="6.22" ry="6.22" transform="translate(180 90)"/>
      <rect width="60" height="15" rx="6.22" ry="6.22" transform="translate(180 150)"/>
      <rect width="60" height="15" rx="6.22" ry="6.22" transform="translate(180 30)"/>
      <rect width="30" height="15" rx="6.22" ry="6.22" transform="translate(60 60)"/>
      <rect width="30" height="15" rx="6.22" ry="6.22" transform="translate(240 60)"/>
      <rect width="30" height="15" rx="6.22" ry="6.22" transform="translate(150 60)"/>
    </g>
  </svg>
);

export function SideNavigation() {
  const { theme, setTheme } = useTheme();
  const [currentSection, setCurrentSection] = useState(0);
  const [logoExpanded, setLogoExpanded] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [hoveredButton, setHoveredButton] = useState<number | null>(null);
  const [leetText, setLeetText] = useState<{ [key: number]: string }>({});
  const [clickedButtons, setClickedButtons] = useState<Set<number>>(new Set());

  const navigateToSection = (sectionIndex: number) => {
    const event = new CustomEvent('travel-navigate', { detail: { index: sectionIndex } });
    window.dispatchEvent(event);
    setCurrentSection(sectionIndex);
    setClickedButtons(prev => new Set(Array.from(prev).concat(sectionIndex)));
  };

  const navItems = [
    { icon: Layers, label: "PROBLEMS", section: 1, description: "Problem stack" },
    { icon: Grid3X3, label: "SCHEMA", section: 2, description: "Brand schema" },
    { icon: Bot, label: "AGENTS", section: 3, description: "AI agents" },
    { icon: Wrench, label: "TOOLS", section: 4, description: "Tool zone" },
  ];

  // Listen for section changes
  useEffect(() => {
    const handleSectionChange = (e: CustomEvent) => {
      setCurrentSection(e.detail.currentSection);
    };

    window.addEventListener('section-changed', handleSectionChange as EventListener);
    
    return () => {
      window.removeEventListener('section-changed', handleSectionChange as EventListener);
    };
  }, []);

  // Leet text animation for hovered buttons
  const animateLeetText = (buttonIndex: number, originalText: string) => {
    const randomChars = "!@#$%^&*()_+[]{}|;:,.<>?";
    const leetMap: { [key: string]: string } = {
      'A': '4', 'E': '3', 'I': '1', 'O': '0', 'S': '5', 'T': '7'
    };
    
    let step = 0;
    const totalSteps = 15;
    
    const animate = () => {
      if (step < totalSteps && hoveredButton === buttonIndex) {
        const progress = step / totalSteps;
        let newText = "";
        
        for (let i = 0; i < originalText.length; i++) {
          const char = originalText[i];
          if (progress < 0.3) {
            newText += randomChars[Math.floor(Math.random() * randomChars.length)];
          } else if (progress < 0.7) {
            newText += leetMap[char] || char;
          } else {
            newText += char;
          }
        }
        
        setLeetText(prev => ({ ...prev, [buttonIndex]: newText }));
        step++;
        setTimeout(animate, 33);
      } else {
        setLeetText(prev => ({ ...prev, [buttonIndex]: originalText }));
      }
    };
    
    animate();
  };

  const handleButtonHover = (buttonIndex: number, label: string) => {
    setHoveredButton(buttonIndex);
    animateLeetText(buttonIndex, label);
  };

  const handleButtonLeave = (buttonIndex: number, label: string) => {
    setHoveredButton(null);
    setLeetText(prev => ({ ...prev, [buttonIndex]: label }));
  };

  return (
    <>
      {/* Permanent Logo */}
      <div 
        className="permanent-logo"
        onMouseEnter={() => {
          setLogoExpanded(true);
          setTimeout(() => setShowMenu(true), 300);
        }}
        onMouseLeave={() => {
          setLogoExpanded(false);
          setShowMenu(false);
        }}
        onClick={() => navigateToSection(0)}
      >
        <GlossyBrandLogo />
        <div className={`logo-wordmark ${logoExpanded ? 'expanded' : ''}`}>
          <div className="wordmark-line">BRAND</div>
          <div className="wordmark-line">
            SCHEMA
            <span className="colon-flash">:</span>
          </div>
        </div>
        
        {/* Glassmorphic Menu Strip */}
        <div className={`menu-strip ${showMenu ? 'visible' : ''}`}>
          {navItems.map((item, index) => (
            <button
              key={index}
              onClick={(e) => {
                e.stopPropagation();
                navigateToSection(item.section);
              }}
              onMouseEnter={() => handleButtonHover(index, item.label)}
              onMouseLeave={() => handleButtonLeave(index, item.label)}
              className={`neumorphic-button ${
                currentSection === item.section ? 'active' : ''
              } ${clickedButtons.has(item.section) ? 'illuminated' : ''}`}
              aria-label={item.label}
            >
              <div className="button-content">
                <item.icon size={18} className="button-icon" />
                <span className="button-label">
                  {leetText[index] || item.label}
                </span>
              </div>
            </button>
          ))}
          
          {/* Theme Toggle */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setTheme(theme === "light" ? "dark" : "light");
            }}
            className="neumorphic-button theme-button"
            aria-label="Toggle theme"
          >
            <div className="button-content">
              {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
              <span className="button-label">THEME</span>
            </div>
          </button>
        </div>
      </div>
    </>
  );
}