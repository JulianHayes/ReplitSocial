# BRAND:SCHEMA - Brutalist Retrofuturist Interface

## Overview

BRAND:SCHEMA is a full-stack web application built with React and Express that presents a brutalist-inspired, retrofuturist interface designed to feel like a semantic operating system rather than a traditional website. The project features an immersive 3D tunnel navigation system that creates the sensation of traveling forward through dimensional zones rather than traditional scrolling. The interface emphasizes deep Z-axis movement, glitch aesthetics, and depth-based lighting effects for brand schema visualization and agent-based interactions.

Recently redesigned with a permanent glossy logo system (#ff0b00) that expands to reveal BRAND:SCHEMA wordmark, featuring neumorphic buttons on a glassmorphic strip.

## User Preferences

Preferred communication style: Simple, everyday language.

## Consolidated Design Requirements

### Permanent Logo Navigation System (Latest Priority)
- **Logo Color**: Specifically #ff0b00 with glossy gradient effects
- **Position**: Fixed in top-left corner, acts as HOME button
- **Wordmark Expansion**: On hover, logo expands to show two-line wordmark:
  - Line 1: "BRAND" 
  - Line 2: "SCHEMA" with flashing colon (:)
- **Typography**: JetBrains Mono extra bold for wordmark
- **Glassmorphic Menu Strip**: Appears below logo on hover with backdrop blur and transparency
- **Neumorphic Buttons**: Rounded buttons with proper shadows, gradients, and depth effects
- **Leet Text Animation**: 0.5-second random character scramble on button hover before settling to actual text
- **Icon Illumination**: Clicked buttons have glowing animated icons in #ff0b00
- **Theme Default**: Light mode as default instead of dark mode
- **Clean Design**: Remove old slide-in navigation system completely

### Navigation Behavior
- Logo hover triggers wordmark expansion (300ms delay)
- Menu strip appears with glassmorphic backdrop blur
- Buttons feature neumorphic styling with depth shadows
- Hover triggers leet text scrambling animation
- Click illuminates icons with #ff0b00 glow effect
- Smooth transitions using cubic-bezier(0.4, 0, 0.2, 1)

### UI/UX Design Philosophy
- **Brutalist Retrofuturist**: Sharp edges, high contrast, minimal decoration combined with futuristic elements
- **Semantic OS Feel**: Interface designed as a live schema rather than static website
- **3D Tunnel Navigation**: Deep Z-axis movement creating forward travel through dimensional zones
- **Immersive Depth**: Multi-layered lighting effects and floating particles for spatial awareness
- **Glitch Aesthetics**: Text distortion on hover and random tile animations
- **Full-Screen Snap Panels**: Sections that occupy full viewport with smooth transitions

### Technical Implementation Standards
- **React 18** with TypeScript for frontend
- **Express.js** backend with RESTful API design
- **Tailwind CSS** for styling with custom brutalist/retrofuturist design tokens
- **Framer Motion** for smooth transitions and glitch effects
- **JetBrains Mono** typography for technical aesthetic
- **Mobile-First**: Responsive design with fixed navigation and footer on mobile
- **Light Mode Default**: Application starts in light mode, dark mode available via toggle

### Visual Elements
- **Custom Cursor**: Red dot with blend mode effects following pointer
- **Ambient Backgrounds**: Section-specific 3D atmospheric effects with floating particles
- **Vellum Interfaces**: Glassmorphic panels with depth-based lighting and mouse-reactive effects
- **Depth Particles**: Floating animated elements at various Z-levels creating spatial awareness
- **Status Lights**: Animated dots indicating system status with randomized colors
- **Footer**: Structured layout with periodic table-style social links ([Ds], [Rd], [Li], [Gh])

### Animation Specifications
- **Wordmark Expansion**: 0.4s cubic-bezier transition
- **Leet Text**: 0.5s random character scramble on hover
- **Icon Glow**: 2s ease-in-out infinite alternate animation
- **Colon Flash**: 1.5s infinite opacity animation (1s visible, 0.5s hidden)
- **Glitch Effects**: 0.2s ease-in-out text distortion
- **Menu Strip**: 0.3s cubic-bezier fade-in with 10px translateY

### Color Palette
- **Primary Brand**: #ff0b00 (bright red-orange)
- **Brand Orange**: #FF4500 
- **Brand Red**: #DC143C
- **Brand Green**: #00FF00
- **Glassmorphic**: rgba(255, 255, 255, 0.1) with backdrop-filter blur(20px)
- **Neumorphic Light**: linear-gradient(145deg, #f0f0f0, #e0e0e0)
- **Neumorphic Shadow**: 8px 8px 16px rgba(0, 0, 0, 0.1), -8px -8px 16px rgba(255, 255, 255, 0.8)

### Content Structure
- **Hero Section**: Main landing with large impact typography
- **Problem Stack**: Three-column grid highlighting key challenges
- **Schema Grid**: Brand schema visualization with file-like structure
- **Agent Panel**: Display of different AI agents with status indicators
- **Tool Zone**: Interactive tools and utilities section

## CONSOLIDATED PROMPT FOR FUTURE REFERENCE

Build BRAND:SCHEMA - a brutalist retrofuturist semantic interface that functions like an operating system with:

1. **Permanent Glossy Logo System** (#ff0b00):
   - Fixed top-left position acting as HOME button
   - Expands on hover to show "BRAND" / "SCHEMA:" wordmark in JetBrains Mono extra bold
   - Flashing colon animation (1.5s cycle)
   - Glassmorphic menu strip appears below on hover

2. **Neumorphic Navigation Buttons**:
   - Rounded buttons with proper depth shadows and gradients
   - 0.5-second leet text scramble animation on hover
   - Icon illumination in #ff0b00 on click with glow animation
   - Glassmorphic strip with backdrop blur effects

3. **3D Tunnel Navigation**:
   - Full-screen snap panels with deep Z-axis movement
   - 1500px perspective creating forward travel sensation
   - Ambient 3D backgrounds with floating particles
   - Immersive depth-based lighting effects

4. **Brutalist Retrofuturist Design**:
   - Sharp edges, high contrast, technical monospace typography
   - Glowing effects, animated status lights, digital aesthetics
   - Custom red dot cursor with blend modes
   - Random glitch effects on tiles and text distortion

5. **Technical Stack**:
   - React 18 + TypeScript + Express.js
   - Tailwind CSS with custom design tokens
   - Framer Motion for animations
   - Light mode as default, dark mode toggle available
   - Mobile-responsive with fixed navigation

The interface should feel like a live semantic operating system rather than a traditional website, emphasizing spatial awareness through multi-layered effects and creating an immersive dimensional experience.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom brutalist/retrofuturist design tokens
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Animations**: Framer Motion for smooth transitions and glitch effects
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: In-memory storage (development) with planned PostgreSQL integration
- **API Design**: RESTful API with /api prefix routing

### Key Design Principles
- **Brutalist Aesthetics**: Sharp edges, high contrast, minimal decoration
- **Retrofuturist Elements**: Glowing effects, animated status lights, digital clock-style pulsing
- **Semantic OS Feel**: Interface designed as a live schema rather than static website
- **3D Tunnel Navigation**: Deep Z-axis movement creating forward travel through dimensional zones
- **Immersive Depth**: Multi-layered lighting effects and floating particles for spatial awareness
- **Mobile-First**: Responsive design with fixed navigation and footer on mobile

## Key Components

### UI Components
- **Custom Cursor**: Red dot with blend mode effects following pointer
- **Side Navigation**: Slide-out side panel with section navigation, theme toggle, and animated logo
- **Tunnel Navigation System**: Deep Z-axis movement with 1500px perspective and multi-layer transitions
- **Ambient Backgrounds**: Section-specific 3D atmospheric effects with floating particles
- **Vellum Interfaces**: Glassmorphic panels with depth-based lighting and mouse-reactive effects
- **Depth Particles**: Floating animated elements at various Z-levels creating spatial awareness
- **Footer**: Structured layout with periodic table-style social links ([Ds], [Rd], [Li], [Gh])
- **Status Lights**: Animated dots indicating system status with randomized colors
- **Glitch Effects**: Text distortion on hover and random tile animations

### Content Sections
- **Hero**: Main landing section with large impact typography
- **Problem Stack**: Three-column grid highlighting key challenges
- **Schema Grid**: Brand schema visualization with file-like structure
- **Agent Panel**: Display of different AI agents with status indicators
- **Tool Zone**: Interactive tools and utilities section

### Theme System
- **Dark/Light Mode**: Toggle between themes with CSS custom properties
- **Color Palette**: Brand orange (#FF4500), brand red (#DC143C), brand green (#00FF00)
- **Typography**: Monospace fonts for technical aesthetic
- **Glass Morphism**: Semi-transparent navigation and UI elements

## Data Flow

### Client-Server Communication
1. **API Requests**: Frontend uses fetch with custom apiRequest wrapper
2. **Query Management**: TanStack Query handles caching and synchronization
3. **Error Handling**: Centralized error handling with toast notifications
4. **Authentication**: Credential-based sessions (planned implementation)

### State Management
- **Server State**: Managed by TanStack Query with automatic caching
- **Client State**: React hooks and context for theme, mobile detection
- **Form State**: React Hook Form with Zod validation (planned)

### Database Schema
- **Users Table**: Basic user management with username/password
- **Session Management**: PostgreSQL-based sessions with connect-pg-simple
- **Migrations**: Drizzle migrations in ./migrations directory

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **framer-motion**: Animation library
- **wouter**: Lightweight routing

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and development experience
- **Tailwind CSS**: Utility-first styling
- **PostCSS**: CSS processing
- **ESBuild**: Production bundling

### UI Enhancement
- **class-variance-authority**: Component variant management
- **clsx**: Conditional className utilities
- **cmdk**: Command palette component
- **embla-carousel-react**: Carousel functionality
- **date-fns**: Date manipulation utilities

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot module replacement
- **Database**: Neon Database with environment-based configuration
- **Environment Variables**: DATABASE_URL required for database connection

### Production Build
- **Frontend**: Vite build outputs to dist/public
- **Backend**: ESBuild bundles server code to dist/index.js
- **Static Assets**: Served from dist/public directory
- **Database Migrations**: Drizzle push commands for schema updates

### Hosting Requirements
- **Node.js**: ESM support required
- **Environment Variables**: DATABASE_URL must be configured
- **Static File Serving**: Express serves built frontend assets
- **Database**: PostgreSQL-compatible database (Neon recommended)

### Performance Considerations
- **Code Splitting**: Automatic with Vite
- **Asset Optimization**: Vite handles minification and compression
- **Database Queries**: Drizzle ORM with prepared statements
- **Caching**: TanStack Query provides client-side caching

The application is designed to be deployed on platforms like Replit, Vercel, or similar Node.js hosting services with PostgreSQL database support.